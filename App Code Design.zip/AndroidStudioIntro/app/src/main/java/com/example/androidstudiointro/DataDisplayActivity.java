package com.example.androidstudiointro;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import android.widget.ArrayAdapter;
import android.widget.ListView;


public class DataDisplayActivity extends AppCompatActivity {
    private EditText editTextDate;
    private EditText editTextWeight;
    private Button addDataButton;
    private ListView listViewEntries;
    private DatabaseHelper databaseHelper;
    private ArrayAdapter<String> adapter;
    private List<String> entries;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);
        addDataButton = findViewById(R.id.addDataButton);
        listViewEntries = findViewById(R.id.listViewEntries);

        databaseHelper = new DatabaseHelper(this);

        entries = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, entries);
        listViewEntries.setAdapter(adapter);

        loadData();

        addDataButton.setOnClickListener(v -> {
            addData();
            loadData(); // Reload data
        });
    }

    private void loadData() {
        List<String> newEntries = databaseHelper.getAllEntries();
        entries.clear();
        entries.addAll(newEntries);
        adapter.notifyDataSetChanged();
    }

    private void addData() {
        String date = editTextDate.getText().toString().trim();
        String weightStr = editTextWeight.getText().toString().trim();
        if (!date.isEmpty() && !weightStr.isEmpty()) {
            try {
                double weight = Double.parseDouble(weightStr);
                long userId = getUserId(); // Fetch the user ID
                if (userId != -1 && databaseHelper.addWeightEntry(date, weight, userId)) {
                    Toast.makeText(this, "Data added successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Failed to add data", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid weight format", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter both date and weight", Toast.LENGTH_SHORT).show();
        }
    }

    private long getUserId() {
        SharedPreferences sharedPreferences = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        return sharedPreferences.getLong("USER_ID", -1);
    }
}
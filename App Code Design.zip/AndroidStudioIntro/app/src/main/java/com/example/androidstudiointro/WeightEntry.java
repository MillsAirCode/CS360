package com.example.androidstudiointro;

public class WeightEntry {
    private int id;
    private String date;
    private double weight;
    private int userId;

    public WeightEntry(int id, String date, double weight, int userId) {
        this.id = id;
        this.date = date;
        this.weight = weight;
        this.userId = userId;
    }

    // Getter methods
    public int getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public double getWeight() {
        return weight;
    }

    public int getUserId() {
        return userId;
    }
}

package com.example.androidstudiointro;

import static android.content.Context.MODE_PRIVATE;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHT_ENTRIES = "weight_entries";
    private static final String KEY_ID = "id";
    private static final String KEY_DATE = "date";
    private static final String KEY_WEIGHT = "weight";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public long getUserId(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("AppPrefs", MODE_PRIVATE);
        return sharedPreferences.getInt("USER_ID", -1);  // Return -1 if no user ID found
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_USERNAME + " TEXT UNIQUE,"
                + KEY_PASSWORD + " TEXT"
                + ")";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_WEIGHT_ENTRIES_TABLE = "CREATE TABLE " + TABLE_WEIGHT_ENTRIES + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_DATE + " TEXT,"
                + KEY_WEIGHT + " REAL,"
                + KEY_USER_ID + " INTEGER,"
                + "FOREIGN KEY(" + KEY_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + KEY_ID + "))";
        db.execSQL(CREATE_WEIGHT_ENTRIES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT_ENTRIES);
        onCreate(db);
    }

    public boolean addWeightEntry(String date, double weight, long userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_DATE, date);
        values.put(KEY_WEIGHT, weight);
        values.put(KEY_USER_ID, userId);
        long result = db.insert(TABLE_WEIGHT_ENTRIES, null, values);
        db.close();
        return result != -1;
    }

    public List<String> getAllEntries() {
        List<String> entries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_WEIGHT_ENTRIES, new String[]{KEY_DATE, KEY_WEIGHT}, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                String date = "";
                double weight = 0.0;

                int dateIndex = cursor.getColumnIndex(KEY_DATE);
                if (dateIndex != -1) {
                    date = cursor.getString(dateIndex);
                }

                int weightIndex = cursor.getColumnIndex(KEY_WEIGHT);
                if (weightIndex != -1) {
                    weight = cursor.getDouble(weightIndex);
                }

                entries.add(date + ": " + weight + " kg");
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return entries;
    }

    public WeightEntry getWeightEntryById(int weightId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_WEIGHT_ENTRIES, new String[]{KEY_DATE, KEY_WEIGHT, KEY_USER_ID},
                KEY_ID + "=?", new String[]{String.valueOf(weightId)}, null, null, null);
        WeightEntry weightEntry = null;
        if (cursor != null && cursor.moveToFirst()) {
            String date;
            double weight;
            int userId;

            int dateIndex = cursor.getColumnIndex(KEY_DATE);
            if (dateIndex != -1) {
                date = cursor.getString(dateIndex);
            } else {
                date = ""; // Assign default value
            }

            int weightIndex = cursor.getColumnIndex(KEY_WEIGHT);
            if (weightIndex != -1) {
                weight = cursor.getDouble(weightIndex);
            } else {
                weight = 0.0; // Assign default value
            }

            int userIdIndex = cursor.getColumnIndex(KEY_USER_ID);
            if (userIdIndex != -1) {
                userId = cursor.getInt(userIdIndex);
            } else {
                userId = -1; // Assign default value
            }

            weightEntry = new WeightEntry(weightId, date, weight, userId);
            cursor.close();
        }
        db.close();
        return weightEntry;
    }



    public boolean updateWeightEntry(int weightId, String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_DATE, date);
        values.put(KEY_WEIGHT, weight);
        int updateCount = db.update(TABLE_WEIGHT_ENTRIES, values, KEY_ID + " = ?", new String[]{String.valueOf(weightId)});
        db.close();
        return updateCount > 0;
    }

    public boolean deleteWeightEntry(int weightId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int deleteCount = db.delete(TABLE_WEIGHT_ENTRIES, KEY_ID + " = ?", new String[]{String.valueOf(weightId)});
        db.close();
        return deleteCount > 0;
    }

    public long login(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        long userId = -1; // Default to failure
        Cursor cursor = db.query(TABLE_USERS, new String[]{KEY_ID}, KEY_USERNAME + "=? AND " + KEY_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);
        if (cursor.moveToFirst()) {
            userId = cursor.getLong(0); // Assuming KEY_ID is at index 0
        }
        cursor.close();
        db.close();
        return userId;
    }


    public long register(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            if (userExists(username, db)) {
                return -1; // Username already exists
            }
            ContentValues values = new ContentValues();
            values.put(KEY_USERNAME, username);
            values.put(KEY_PASSWORD, password);
            long userId = db.insert(TABLE_USERS, null, values);
            return userId == -1 ? -1 : userId;
        } finally {
            db.close();
        }
    }

    private boolean userExists(String username, SQLiteDatabase db) {
        boolean exists = false;
        Cursor cursor = db.query(TABLE_USERS, new String[]{KEY_ID}, KEY_USERNAME + "=?",
                new String[]{username}, null, null, null);
        if (cursor.moveToFirst()) {
            exists = true;
        }
        cursor.close();
        return exists;
    }
}

package com.example.androidstudiointro;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLoginActivity();
            }
        });

        Button btnDataDisplay = findViewById(R.id.btnDataDisplay);
        btnDataDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDataDisplayActivity();
            }
        });

        Button btnPermissionRequest = findViewById(R.id.btnPermissionRequest);
        btnPermissionRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPermissionRequestActivity();
            }
        });

        // Adding button for navigating to ChartActivity
        Button btnChartDisplay = findViewById(R.id.btnChartDisplay);
        btnChartDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openChartActivity();
            }
        });
    }

    private void openLoginActivity() {
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
    }

    private void openDataDisplayActivity() {
        Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
        startActivity(intent);
    }

    private void openPermissionRequestActivity() {
        Intent intent = new Intent(MainActivity.this, PermissionRequestActivity.class);
        startActivity(intent);
    }

    // Method to navigate to ChartActivity
    private void openChartActivity() {
        Intent intent = new Intent(MainActivity.this, ChartActivity.class);
        startActivity(intent);
    }
}

package com.example.androidstudiointro;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class ChartActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);  // Replace 'activity_chart' with your actual layout file name

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        WebView chartActivity = findViewById(R.id.webview); // Update to match your WebView ID

        chartActivity.getSettings().setJavaScriptEnabled(true);  // Enable JavaScript execution
        chartActivity.getSettings().setLoadWithOverviewMode(true);  // Zoom out the content to fit on screen by width
        chartActivity.getSettings().setUseWideViewPort(true);  // Enables the "viewport" HTML meta tag to be used in the WebView

        chartActivity.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // This is a good place to inject JavaScript or handle anything after page load
                // Retrieve data from the database and pass it to the JavaScript function
                List<String> weightEntries = databaseHelper.getAllEntries();
                String data = formatDataForJavaScript(weightEntries);
                chartActivity.evaluateJavascript("javascript:drawChart(" + data + ");", null);
            }
        });

        chartActivity.loadUrl("file:///android_asset/chart.html");  // Load your local HTML file from the assets folder
    }

    // Format data into the appropriate format for JavaScript
    private String formatDataForJavaScript(List<String> weightEntries) {
        StringBuilder jsonData = new StringBuilder("[");
        for (String entry : weightEntries) {
            jsonData.append("\"").append(entry).append("\", ");
        }
        if (!weightEntries.isEmpty()) {
            jsonData.delete(jsonData.length() - 2, jsonData.length());  // Remove the last comma and space
        }
        jsonData.append("]");
        return jsonData.toString();
    }
}
